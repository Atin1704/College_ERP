package com.company.Mainusers;
//all exception are present here
//9 exceptions in in total, 1 more for login and 5 more for add course
public class UnknownEmailException extends Exception {
    
    public UnknownEmailException(String email) {
        
        super("Unknown email exception "+ email);
    }
}


class PasswordMismatchException extends Exception {
    public PasswordMismatchException(String username) {
        super("Password doesn't match exception    " + username);
    }
}



class AddCourseException1 extends Exception {
    public AddCourseException1() {
        super("InvalidCourseCodeException   " );
    }
}

class AddCourseException2 extends Exception {
    public AddCourseException2() {
        super("CourseAlreadyPresentException   " );
    }
}


class AddCourseException3 extends Exception {
    public AddCourseException3() {
        super("CourseNotInSemException  " );
    }
}

class AddCourseException4 extends Exception {
    public AddCourseException4() {
        super("2OCreditLimitExceededException   " );
    }
}




class AddCourseException5 extends Exception {
    public AddCourseException5() {
        super("PrereqNotMetException  " );
    }
}


class AddCourseException6 extends Exception {
    public AddCourseException6() {
        super("Courselimitexceeded   " );
    }
}





class DropCourseException extends Exception {
    public DropCourseException(String username) {
        super("CourseDropDeadlinePassedException   " + username);
    }
}

