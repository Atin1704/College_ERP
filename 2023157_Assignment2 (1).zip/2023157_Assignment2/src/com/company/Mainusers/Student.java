package com.company.Mainusers;

import java.util.Scanner;

public class Student extends User implements Interfacesforstudent {

    @Override
    public String Startprocedure() {
        Boolean checkemail = false;
        Scanner scanner = new Scanner(System.in);
        String emailid = null;
    
        // Email input loop
        while (!checkemail) {
            System.out.println("Welcome student\nPlease provide your email address");
            emailid = scanner.next();
    
            try {
                checkemail = Student_checker(emailid); // Check if email exists in student records
                if (!checkemail) {
                    throw new UnknownEmailException(emailid);
                }
            } catch (UnknownEmailException e) {
                System.out.println(e.getMessage());
            }
        }
    
        this.email = emailid; // Assign the email if it exists
    
        // Password input loop
        Boolean checkpassword = false;
        int attempts = 0;
    
        while (!checkpassword && attempts < 3) {
            String passwdexistence = Student_getter(this.email); // Get password for student email
    
            try {
                if (passwdexistence == null) {
                    // Creating a new password
                    checkpassword = createPassword(scanner);
                } else {
                    // Verifying the existing password
                    checkpassword = verifyPassword(scanner, passwdexistence);
                }
            } catch (PasswordMismatchException e) {
                System.out.println(e.getMessage() + ", try again.");
            }
    
            attempts++;
        }
    
        if (attempts >= 3) {
            System.out.println("Too many attempts, returning to login page");
            return "0"; // Return to login after too many attempts
        }
    
        String nextstep = null;
        System.out.println("Main directory");
        while (!"0".equals(nextstep) && !"-1".equals(nextstep)) {
            User.Entry(); 
            nextstep = scanner.next();
            if ("2".equals(nextstep)) {
                nextstep = showfunctionalities(); 
                if ("1".equals(nextstep)) {
                    System.out.println("Main directory");
                    continue;
                }
            } else if ("0".equals(nextstep) || "-1".equals(nextstep)) {
                break;
            } else {
                System.out.println("Invalid input, try again");
            }
        }
        return nextstep;
    }
    
    private boolean createPassword(Scanner scanner) throws PasswordMismatchException {
        System.out.println("Create a new password:");
        String passwd1 = scanner.next();
        System.out.println("Re-enter password:");
        String passwd2 = scanner.next();
    
        if (passwd1.equals(passwd2)) {
            Student_setter(this.email, passwd1); // Set the new password for student
            System.out.println("Password created successfully.");
            return true;
        } else {
            throw new PasswordMismatchException("Passwords do not match.");
        }
    }
    
    private boolean verifyPassword(Scanner scanner, String expectedPassword) throws PasswordMismatchException {
        System.out.println("Enter your password:");
        String passwdEntered = scanner.next();
    
        if (expectedPassword.equals(passwdEntered)) {
            System.out.println("Password entered correctly.");
            return true; // Password entered correctly
        } else {
            throw new PasswordMismatchException("Incorrect password.");
        }
    }

    @Override
    public String showfunctionalities() {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        while (!"-1".equals(input) && !"0".equals(input)) {
            Interfacesforstudent.display_main();
            input = scanner.next();
            if ("1".equals(input)) {
                return input;
            } else if ("2".equals(input)) {
                input = ComplaintFunctions.handleComplaints(this);
            } 
            else if("3".equals(input)){
                input=CourseFunctions.handleCourses(this);
            }
            else if ("0".equals(input) || "-1".equals(input)) {
                break;
            } else {
                System.out.println("Invalid input, try again");
            }
        }
        return input;
    }
}