Atin Aggarwal
2023157
branch CSE
//assumptions made
//a student wont select get to select the sme then view the courses, he can only view courses for the current sem he is enrolled in
//for admin to access prof's or student data he needs to provid eethir email id
//when a course is deleted, it can only be deleted for the students that are currently enrolled in it
//for half the students in the pre initialsed data i have provided an email id just to simple thing sup
//to update a complaints  one need to enter its complaint id
//any user ,professor,admin will always have their email id in the sysytem even if the password isnt there,this ensures no one can sign up with any email id..


//how to run?
//cd ~/Desktop/2023157_ASSIGNMENT1/src && javac com/company/Mainusers/*.java && java com.company.Mainusers.Main && find com/company/Mainusers -name "*.class" -delete


//this is strictly for mac os
//also open the src,then com,then company,then mainusers.ajav,then go to main, and if u use vsc yoou run from there,basically that is the package strcuture that needs to be mainated for the code to compile successfully

//also use topleveldata for email id and passwords, rest all initialsed data can be displayed so you won't require it as such
//individual directories for studnet,prof and admin are there but to say they are completely separate would be a lie
//the classes were designed in such a way that you can remove one part and with 5-6 mins changes it would all still work, also data for personal information,academic data ,security daat was different and these in basic are just connected to each other by classes called coursefunctions,complaintfunctions, one part can be detached an used in another completely different program,that is why there are a bit more classes than maybe expected
//OOPS concepts used displayed below
//Inheritance-
Admin inherits from User.
Student inherits from User.
Professor inherits from User.
Admin_complaint inherits from Complaints.
Student_complaint inherits from Complaints.
User inherits from Topleveldata
Personal_info_methods inherits from Studentpersonal_info
why inheritance used-allowed me to use polymorphism(run-time),use functions and data present in the class that was inherited
//classes
multiple classes created, used to create data types such as Course,Stdacad(sem,email,ampping),Complaint,User(name,email),etc.they are helping to achive modularity, in my implementation scalibilityand independenece too, their ability to being inherited is being widely used, the data type created is also extremeley crucial for the assignment as it helps keep data seperate as well as has neough functionlaities to get thru the tough challnges that may be fcaed while doing a project like this....
//Encapsulation
Provided in almost all of the top level classes like Topleveldata,Studentpersonal_info,Stdacad,Courses,Complaints,etc to provide a safe method to access data from these classes with the use of  multiple getters and setters and private and protected access modifiers
//Abstraction&&Interface
User is an abstract class , it is inherited by prof,student and admin ,provides basic template and it provides referehnce to provide run time polymorphism and kickstart the code
Interface for students,admin,prof,can be called as containers for what different menu are being printed,used thru interfaces rather than creating a class as multiple interfaces can be implemented by a class
ex.in Coursefunctions and ComplaintFunctions,etc
Interface named course runner implemented by studnet course, admincourse runner, professor course runner, help to porvide basic template and provide run time polymorphism
basically all these classes were used for interfaces were used for hiding complexity,simplification,simplifying functions epsecially those in Courserunner types,helping the code be easier to read and maintain
//Polymorphism
Run time-Thru user(see in main),Thru courserunner(see in Course functions)
Compile time-Used in complaintfunctions ,seeing the user passed is an instance of what/student,prof and admin and then running the necessary data
why did i use it? it provides one can say a single point of refernce, makes the code more mnaegabel and easier to read,runand most importantly to code
//other oops concepts 
course and stdacad have a compositiona nd to some extent association relationship,etc.
complaint has associated relationship with top level data,stdunet complaints,admin complaints,etc.
Courses,Stdacad and Complaints are dependent on Coursefunctions and complaint functions respectively
interfacesforstudnet is associated with studnetcourse,stdacad too
there are multiple such association,dependence and composition relationships,etc in the assignment













