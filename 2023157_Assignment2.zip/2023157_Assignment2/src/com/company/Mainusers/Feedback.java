package com.company.Mainusers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
//concept of generic class used here for storing course feedback,also has a method for viewing feedback
public class Feedback<T> {
    private T fdbck;
    private String emailid;
    private String coursecode;

    //  map course code to a list of Feedback
    private static HashMap<String, List<Feedback<?>>> feedbackMap = new HashMap<>();

    
    public Feedback(T data, String emailid, String code) {
        this.fdbck = data;
        this.emailid = emailid;
        this.coursecode = code;

        // Add the feedback to the static hashmap
        feedbackMap.computeIfAbsent(code, k -> new ArrayList<>()).add(this);
    }

    // Getters and Setters
    public T getFdbck() {
        return fdbck;
    }

    public void setFdbck(T fdbck) {
        this.fdbck = fdbck;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getCoursecode() {
        return coursecode;
    }

    public void setCoursecode(String coursecode) {
        this.coursecode = coursecode;
    }

    public static void viewFeedbackForCourse(String courseCode) {
        if (feedbackMap.containsKey(courseCode)) {
            List<Feedback<?>> feedbackList = feedbackMap.get(courseCode);
            System.out.println("Feedback for Course: " + courseCode);
            for (Feedback<?> feedback : feedbackList) {
                System.out.println("Email: " + feedback.getEmailid());
                System.out.println("Feedback: " + feedback.getFdbck());
                System.out.println("-------------------------");
            }
        } else {
            System.out.println("No feedback found for course: " + courseCode);
        }
    }

    // Static block to initialize some feedback
    static {
        
        new Feedback<>("Good course", "a2@iiiitd.ac.in", "CS2");
        new Feedback<>(5, "a1@iiiitd.ac.in", "CS1");
    }

   
}
