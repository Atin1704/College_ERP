package com.company.Mainusers;

import java.util.ArrayList;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Studentcourserunner implements Courserunner {
    @Override
    public void displaycourses(String emailid) {
        // Retrieve the student instance using the provided email ID
        Stdacad student = Stdacad.get_instance(emailid);
        if (student == null) {
            System.out.println("Error: Student not found.");
            return;
        }
    
        // Get the student's current semester
        char currentSem = student.getSem();
    
        // Retrieve courses for the current semester
        ArrayList<Course> courses = Course.getCoursesForSemester(currentSem);
        
        // Display course information
        System.out.println("Courses for Semester " + currentSem + ":");
        for (Course course : courses) {
            System.out.println("Course Code: " + course.getCoursecode());
            System.out.println("Title: " + course.getCoursetitle());
            System.out.println("Credits: " + course.getCourseCredits());
            System.out.println("Location: " + course.getLocation());
            System.out.println("Schedule: " + course.getSchedule());
            System.out.println("Day: " + course.getDay());
            System.out.println("Office Hours: " + course.getOfficehrs());
            System.out.println("Professor Email: " + course.getProfEmailId());
            System.out.println("Student Limit: " + course.getStudent_limit());
            System.out.println("Drop Date: " + course.getDropDate());
    
            // Retrieve and display prerequisites
            ArrayList<String> prerequisites = getPrerequisitesDisplay(course.getCoursecode());
            if (prerequisites.isEmpty()) {
                System.out.println("Prerequisites: None");
            } else {
                System.out.println("Prerequisites: " + String.join(", ", prerequisites));
            }
            
            System.out.println("-------------------------------");
        }
    }
    

    @Override
    public void displaystudentdata(String emailid) {
        Scanner scanner = new Scanner(System.in);
        Stdacad student = Stdacad.getStudentByEmail(emailid);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.println("Enter 1 for GPA");
        System.out.println("Enter 2 for SGPA");
        String input = scanner.next();

        switch (input) {
            case "1":
                System.out.println("Your GPA is: " + student.calculateGPA());
                break;
            case "2":
                System.out.println("Enter semester to calculate SGPA:");
                char semInput = scanner.next().charAt(0);

                // Validate semester input
                if (semInput > student.getSem()) {
                    System.out.println("Invalid semester. It cannot be greater than your current semester.");
                } else {
                    double sgpa = student.calculateSGPAWithGrades(semInput);
                    // if (sgpa != -1.0) {
                    //     System.out.println("SGPA for semester " + semInput + " is: " + sgpa);
                    // } else {
                    //     System.out.println("SGPA does not exist for semester " + semInput + ".");
                    // }
                }
                break;
            default:
                System.out.println("Invalid input.");
                break;
        }
    }


public String update_data(String emailid) {
   
    Stdacad student = Stdacad.get_instance(emailid);
    Scanner scanner = new Scanner(System.in);

    
    if (student == null) {
        System.out.println("Error: Student not found.");
        return "1"; // Return error code
    }

    
    char currentSem = student.getSem();
    int totalCredits = 0;

    ArrayList<Course> currentCourses = student.getCoursesForSemester(currentSem);
    if (currentCourses != null) {
        for (Course course : currentCourses) {
            totalCredits += course.getCourseCredits(); // Sum up the credits for all courses in the semester
        }
    }

    
    System.out.println("Choose an option:");
    System.out.println("1. Add Course");
    System.out.println("2. Drop Course");

    int choice = scanner.nextInt();
    scanner.nextLine(); 

    if (choice == 1) {
        System.out.println("Enter the course code to add: ");
        String courseCode = scanner.nextLine();
        Course courseToAdd = Course.coursecodeMapping.get(courseCode);
    
        try {
           
            if (courseToAdd == null) {
                throw new AddCourseException1(); // Invalid course code
            }
    
           
            if (currentCourses != null && currentCourses.contains(courseToAdd)) {
                throw new AddCourseException2(); // Course already present
            }
    
           
            if (courseToAdd.getSem() != currentSem) {
                throw new AddCourseException3(); // Course not in current semester
            }
    
            // Check if adding this course would exceed the 20-credit limit
            if (totalCredits + courseToAdd.getCourseCredits() > 20) {
                throw new AddCourseException4(); // Credit limit exceeded
            }
    
            
            ArrayList<Course> prerequisites = Course.prereqMapping.get(courseToAdd);
            if (prerequisites != null) {
                for (Course prerequisite : prerequisites) {
                    boolean prereqSatisfied = student.isCourseCompleted(prerequisite);
                    
                    if (!prereqSatisfied) {
                        System.out.println("Error: Unmet prerequisite: " + prerequisite.getCoursecode());
                        throw new AddCourseException5(); // Prerequisite not met
                    }
                }
            }
    
           
            ArrayList<Stdacad> enrolledStudents = Stdacad.course_stdacad_mapping.get(courseToAdd);
            int currentEnrollment = (enrolledStudents != null) ? enrolledStudents.size() : 0;
    
            if (currentEnrollment >= courseToAdd.getStudent_limit()) {
                throw new AddCourseException6(); // Student limit exceeded
            }
    
            // Add the course to the student's current semester
            switch (currentSem) {
                case '1':
                    student.add_course_sem1(courseToAdd, 0);
                    break;
                case '2':
                    student.add_course_sem2(courseToAdd, 0);
                    break;
                case '3':
                    student.add_course_sem3(courseToAdd, 0);
                    break;
                case '4':
                    student.add_course_sem4(courseToAdd, 0);
                    break;
                default:
                    System.out.println("Error: Invalid semester.");
                    return "1";
            }
    
            
            System.out.println("Course " + courseToAdd.getCoursecode() + " added successfully.");
            return "1"; 
    
        } catch (AddCourseException1 e) {
            System.out.println("Error: Invalid course code.");
            return "1"; 
        } catch (AddCourseException2 e) {
            System.out.println("Error: Course already added.");
            return "1"; 
        } catch (AddCourseException3 e) {
            System.out.println("Error: Course is not in the current semester.");
            return "1"; 
        } catch (AddCourseException4 e) {
            System.out.println("Error: Credit limit exceeded.");
            return "1"; 
        } catch (AddCourseException5 e) {
            System.out.println("Error: Prerequisite not met.");
            return "1"; 
        } catch (AddCourseException6 e) {
            System.out.println("Error: Student limit exceeded.");
            return "1"; 
        }
    

    } else if (choice == 2) {
        System.out.println("Enter the course code to drop: ");
    String courseCodeDrop = scanner.nextLine();
    Course courseToDrop = Course.coursecodeMapping.get(courseCodeDrop);

    // Check if the course exists in the current semester
    if (courseToDrop == null || !currentCourses.contains(courseToDrop)) {
        System.out.println("Error: Course not found in your current semester.");
        return "1";
    }

    // Check if the drop deadline has passed
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    Date currentDate = new Date(); // Get the current date
    Date dropDate;

    try {
        dropDate = sdf.parse(courseToDrop.getDropDate()); // Parse the drop date

        // Check if the current date is after the drop date
        if (currentDate.after(dropDate)) {
            throw new DropCourseException(student.getStudentEmailId()); 
        }
    } catch (DropCourseException e) {
        System.out.println(e.getMessage());
        return "1"; 
    } catch (ParseException e) {
        System.out.println("Error: Invalid date format for the drop date.");
        return "1"; 
    }

    // Drop the course from the student's current semester
    switch (currentSem) {
        case '1':
            student.drop_course_sem1(courseToDrop);
            break;
        case '2':
            student.drop_course_sem2(courseToDrop);
            break;
        case '3':
            student.drop_course_sem3(courseToDrop);
            break;
        case '4':
            student.drop_course_sem4(courseToDrop);
            break;
        default:
            System.out.println("Error: Invalid semester.");
            return "1";
    }

    System.out.println("Course " + courseCodeDrop + " dropped successfully.");
    return "1"; 

    } else {
        System.out.println("Error: Invalid option. Please choose 1 or 2.");
        return "1"; 
    }
}





        
    


    


    @Override
    public void display_schedule(String emailid) {
        Stdacad student = Stdacad.getStudentByEmail(emailid);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        char currentSem = student.getSem();
        ArrayList<Course> currentCourses = student.getCoursesForSemester(currentSem);

        if (currentCourses == null || currentCourses.isEmpty()) {
            System.out.println("No courses available for the current semester.");
            return;
        }

        for (Course course : currentCourses) {
            System.out.println("Course: " + course.getCoursecode());
            System.out.println("Location: " + course.getLocation());
            System.out.println("Schedule: " + course.getSchedule());
            System.out.println("Day: " + course.getDay());
            System.out.println("--------------------------------------");
        }
    }

    @Override
    public void display_course_titles(String emailid) {
        Stdacad student = Stdacad.getStudentByEmail(emailid);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        char currentSem = student.getSem();
        ArrayList<Course> currentCourses = student.getCoursesForSemester(currentSem);

        if (currentCourses == null || currentCourses.isEmpty()) {
            System.out.println("No courses available for the current semester.");
            return;
        }

        for (Course course : currentCourses) {
            System.out.println("Course: " + course.getCoursecode());
        }
    }

    
    protected ArrayList<String> getPrerequisitesDisplay(String courseCode) {
        ArrayList<Course> prerequisites = Course.getPrerequisites(courseCode);
        ArrayList<String> prereqTitles = new ArrayList<>();
        for (Course prereq : prerequisites) {
            prereqTitles.add(prereq.getCoursecode());
        }
        return prereqTitles;
    }


    public void addfeedback(String email) {
        
        Stdacad student = Stdacad.get_instance(email);
        if (student == null) {
            System.out.println("Error: Student not found.");
            return;
        }
    
        Scanner scanner = new Scanner(System.in);
    
        
        System.out.println("Enter the semester for which you want to provide feedback:");
        char selectedSem = scanner.next().charAt(0);
    
        // Check if the selected semester is valid (up to the current semester)
        char currentSem = student.getSem();
        if (selectedSem < '1' || selectedSem > currentSem) {
            System.out.println("Invalid semester. Please enter a valid semester up to the current semester.");
            return;
        }
    
        
        ArrayList<Course> selectedSemesterCourses = student.getCoursesForSemester(selectedSem);
    
        
        if (selectedSemesterCourses == null || selectedSemesterCourses.isEmpty()) {
            System.out.println("No courses available for feedback in semester " + selectedSem + ".");
            return;
        }
    
        // Display the courses with corresponding numbers and check if they have grades
        System.out.println("Select a course to provide feedback:");
        ArrayList<Course> eligibleCourses = new ArrayList<>();
        for (int i = 0; i < selectedSemesterCourses.size(); i++) {
            Course course = selectedSemesterCourses.get(i);
            if (student.getGrade(course.getCoursecode()) > 0) { // Check if the student has a grade greater than 0
                // Only display eligible courses
                System.out.println((eligibleCourses.size() + 1) + ". " + course.getCoursetitle() + " (Code: " + course.getCoursecode() + ")");
                eligibleCourses.add(course); // Add to eligible courses list
            }
        }
    
        if (eligibleCourses.isEmpty()) {
            System.out.println("You have no completed courses in semester " + selectedSem + " to provide feedback.");
            return;
        }
    
        // Allow the student to choose a course
        int courseChoice = scanner.nextInt();
        if (courseChoice < 1 || courseChoice > eligibleCourses.size()) {
            System.out.println("Invalid choice. Please select a valid course number.");
            return;
        }
    
        
        Course selectedCourse = eligibleCourses.get(courseChoice - 1);
        String courseCode = selectedCourse.getCoursecode();
    
        // Ask if the student wants to give a rating or text feedback
        System.out.println("Do you want to provide a rating (1-5) or text feedback? Enter '1' for rating or '2' for text feedback:");
        int feedbackType = scanner.nextInt();
        scanner.nextLine(); 
    
        if (feedbackType == 1) {
            System.out.println("Enter your rating (1-5):");
            int rating = scanner.nextInt();
            if (rating < 1 || rating > 5) {
                System.out.println("Invalid rating. Please enter a number between 1 and 5.");
                return;
            }
    
            new Feedback<>(rating, email, courseCode);
            System.out.println("Feedback submitted successfully: Rating " + rating + " for " + selectedCourse.getCoursetitle());
    
        } else if (feedbackType == 2) {
            System.out.println("Enter your feedback:");
            String textFeedback = scanner.nextLine();
    
            // Create feedback instance
            new Feedback<>(textFeedback, email, courseCode);
            System.out.println("Feedback submitted successfully: \"" + textFeedback + "\" for " + selectedCourse.getCoursetitle());
    
        } else {
            System.out.println("Invalid choice. Please enter '1' for rating or '2' for text feedback.");
        }
    }
    
}